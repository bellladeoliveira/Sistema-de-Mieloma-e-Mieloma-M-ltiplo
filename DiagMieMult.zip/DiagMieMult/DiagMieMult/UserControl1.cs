﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DiagMieMult
{
    public partial class UserControl1 : UserControl
    {
        public UserControl1()
        {
            InitializeComponent();
        }

        int pergunta = 0;
        int sims = 0;
        private void UserControl1_Load(object sender, EventArgs e)
        {
            Load_Pergunta(pergunta);
        }

        private void btnSim_Click(object sender, EventArgs e)
        {
            if (pergunta < 6)
            {
                pergunta++;
                sims++;
                Load_Pergunta(pergunta);
            }
            else
            {
                if (sims >= 3)
                {
                    Load_Pergunta(7);
                }
                else
                {
                    Load_Pergunta(8);
                }
            }
        }

        private void btnNao_Click(object sender, EventArgs e)
        {
            if (pergunta < 6)
            {
                pergunta++;
                Load_Pergunta(pergunta);
            } 
            else 
            {
                if (sims >= 3)
                {
                    Load_Pergunta(7);
                } 
                else
                {
                    Load_Pergunta(8);
                }
            }
            
        }

        private void btnConcluido_Click(object sender, EventArgs e)
        {
            if (pergunta < 6)
            {
                pergunta = 1;
                Load_Pergunta(pergunta);
            }
            else
            {
                pergunta = 0;
                Load_Pergunta(pergunta);
            }
            
        }

        private void Load_Pergunta(int numero)
        {
            switch (numero)
            {
                case 0:
                    lblQuestion.Text = "Bem-Vindo\nEste questionário foi criado para ajudar na conscientização e fornecer informações importantes sobre esta condição.";
                    btnConcluido.Visible = true;
                    btnConcluido.Text = "INICIAR";
                    btnSim.Visible = false;
                    btnNao.Visible = false;
                    sims = 0;
                break;

                case 1:
                    lblQuestion.Text = "Pergunta 1:\nVocê sente dores ósseas persistentes?";
                    btnConcluido.Visible = false;
                    btnSim.Visible = true;
                    btnNao.Visible = true;
                break;

                case 2:
                    lblQuestion.Text = "Pergunta 2:\nVocê tem sentido fraqueza e fadiga constante?";
                break;

                case 3:
                    lblQuestion.Text = "Pergunta 3:\nVocê tem tido infecções frequentes ou recorrentes?";
                break;

                case 4:
                    lblQuestion.Text = "Pergunta 4:\nVocê já teve perda de peso não intencional?";
                break;

                case 5:
                    lblQuestion.Text = "Pergunta 5:\nVocê já foi diagnosticado(a) com anemia?";
                break;

                case 6:
                    lblQuestion.Text = "Pergunta 6:\nVocê já foi diagnosticado(a) com hipercalcemia?";
                break;

                case 7:
                    lblQuestion.Text = "Atenção: você apresenta múltiplos sintomas associados ao mieloma múltiplo.\nRecomenda-se que você consulte um médico para uma avaliação mais detalhada.";
                    btnConcluido.Visible = true;
                    btnConcluido.Text = "CONCLUÍDO";
                    btnNao.Visible = false;
                    btnSim.Visible = false;
                break;

                case 8:
                    lblQuestion.Text = "Parece que você apresenta poucos sintomas comuns ao mieloma múltiplo.\nSe os sintomas persistirem ou se intensificarem, procure orientação médica.";
                    btnConcluido.Visible = true;
                    btnConcluido.Text = "CONCLUÍDO";
                    btnNao.Visible = false;
                    btnSim.Visible = false;
                break;

                default:
                    Load_Pergunta(1);
                break;
            }
        }

        
    }
}

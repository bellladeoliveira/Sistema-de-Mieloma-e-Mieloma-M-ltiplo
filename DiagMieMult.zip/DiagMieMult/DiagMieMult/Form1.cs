﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DiagMieMult
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            userControl11.Visible = true;
            userControl21.Visible = false;
            comboBox1.SelectedIndex = 0;
        }

        private void btnDiag_Click(object sender, EventArgs e)
        {
            userControl11.Visible = true;
            userControl21.Visible = false;
        }

        private void btnInfo_Click(object sender, EventArgs e)
        {
            userControl11.Visible = false;
            userControl21.Visible = true;
        }
    }
}
